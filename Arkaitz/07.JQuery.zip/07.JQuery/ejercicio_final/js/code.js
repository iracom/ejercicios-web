$(document).ready(function(){
    // $("#registro").validar({
    //     error : {
    //         requerido : "El campo es requerido",
    //         email : "El campo debe ser un email",
    //         password : "El campo debe ser un password",
    //         url : "El campo debe ser una url"
    //     }
    // });
    $("#registro").validar();
});