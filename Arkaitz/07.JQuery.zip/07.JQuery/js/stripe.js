(function($) {
    $.fn.stripe = function(color) {
        var c = color || '#f1f1f1';
        return this.each(function() {
            $(this).find('tbody tr:odd td').css('backgroundColor', c);
        });
    };
})(jQuery);

// usage: $('#myTable').stripe('#cccccc');
