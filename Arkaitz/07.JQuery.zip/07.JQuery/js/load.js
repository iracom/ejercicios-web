$(document).ready(function() {
    // var $h3 = $("#blog h3");
    // $("#blog .excerpt").remove();

    // $h3.each(function() {
    //     var $this = $(this),
    //         $target = $('<div/>').insertAfter($this);

    //     $this.data('target', $target);
    // })
    // .on('click', 'a', function(e) {
    //     e.preventDefault();

    //     var $this = $(this),
    //         $a = $this.find('a'),
    //         $target = $this.data('target'),
    //         href = $a.attr('href'),
    //         id = '#' + href.split('#')[1];

    //     // $target.load('data/blog.html ' + id);
    //     $.get('data/blog.html', function(html) {
    //         var $html = $(html);

    //         $target.html($html.find(id));
    //     });
    // });

    var $h3 = $('#blog h3');
    $h3.each(function() {
        var $this = $(this),
            $target = $('<div/>').addClass('excerpt').insertAfter($this);

        $this.data('target', $target);
    })
    .on('click', function(e) {
        e.preventDefault();
        
        var $this = $(this),
            $a = $this.find('a'),
            $target = $this.data('target'),
            href = $a.attr('href'),
            id = '#' + href.split('#')[1];

        $target.load('data/blog.html ' + id);
        // $.ajax({
        //     url : 'http://www.arkaitzgarro.com/jquery/data/blog.html',
        //     // url : 'http://www.perfumeriabenegas.com/buscador/amoage',
        //     dataType : 'JSONP',
        //     // data : {
        //     //     _locale: 'es'
        //     // },
        //     success : function(html) {
        //         var $html = $(html);
        //         var $target = $this.data('target');

        //         $target.html($html.filter(id)).slideDown();
        //     }
        // });
     });
});

