$(document).ready(function() {
    var $h3 = $('#blog h3');
    
    $h3.on('click', function(e) {
        e.preventDefault();
        var $this = $(this);
        var $p = $this.next('.excerpt');
        
        $p.slideToggle();
        
        $this.parent().siblings()
            .find('#blog .excerpt:visible').slideUp();
    });
});