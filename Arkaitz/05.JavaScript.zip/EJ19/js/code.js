var $ = function(selector) {
    var e = document.querySelectorAll(selector);
    return (e.length === 1)? e[0] : e;
};

window.onload = function() {
    var info = $(".info");

    var informacion = function(e) {
        var evento = e || window.event;
        var dimensiones = tamanoVentanaNavegador();
        var mensaje = [];

        var centroX = dimensiones[0]/2;
        var centroY = dimensiones[1]/2;

        if(e.clientX < centroX) {
            mensaje.push("Izquierda");
        } else {
            mensaje.push("Derecha");
        }

        if(e.clientY < centroY) {
            mensaje.push("Arriba");
        } else {
            mensaje.push("Abajo");
        }
        
        muestraInformacion.call(info, mensaje);
    }

    var muestraInformacion = function(mensaje) {
        this.innerHTML = '';
        for(var i=0; i<mensaje.length; i++) {
            this.innerHTML += '<p>'+mensaje[i]+'</p>';
        }
    }

    var tamanoVentanaNavegador = function(){
        // Adaptada de http://www.howtocreate.co.uk/tutorials/javascript/browserwindow
        var dimensiones = [];
        
        if(typeof(window.innerWidth) == 'number') {
            // No es IE
            dimensiones = [window.innerWidth, window.innerHeight];
        } else if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
            //IE 6 en modo estandar (no quirks)
            dimensiones = [document.documentElement.clientWidth, document.documentElement.clientHeight];
        } else if(document.body && (document.body.clientWidth || document.body.clientHeight)) {
            //IE en modo quirks
            dimensiones = [document.body.clientWidth, document.body.clientHeight];
        }
        
        return dimensiones;
    }

    document.addEventListener('mousemove', informacion, false);
};