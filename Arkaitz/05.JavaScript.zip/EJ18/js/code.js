var $ = function(selector) {
    var e = document.querySelectorAll(selector);
    return (e.length == 1)? e[0] : e;
};

window.onload = function() {
    var raton = $("#raton .info");
    var teclado = $("#teclado .info");

    function muestraInformacion(mensaje) {
        this.innerHTML = '';
        for(var i=0; i<mensaje.length; i++) {
            this.innerHTML += '<p>'+mensaje[i]+'</p>';
        }
    }

    function infoRaton(e) {
        coordenadaXabsoluta = e.pageX;
        coordenadaYabsoluta = e.pageY;
        coordenadaXrelativa = e.clientX;
        coordenadaYrelativa = e.clientY;
        muestraInformacion.call(raton,
            [
                'Navegador ['+coordenadaXrelativa+', '+coordenadaYrelativa+']',
                'Pagina ['+coordenadaXabsoluta+', '+coordenadaYabsoluta+']'
            ]
        );
    }

    function infoTeclado(e) {
        var caracter = e.charCode || e.keyCode;
        var letra = String.fromCharCode(caracter);
        var codigo = letra.charCodeAt(0);
        muestraInformacion.call(teclado,
            [
                'Carácter ['+letra+']',
                'Código ['+codigo+']'
            ]
        );
    }

    function colorClick() {
        raton.parentNode.style.backgroundColor = '#FFFFCC';
    }

    function colorKey() {
        teclado.parentNode.style.backgroundColor = '#CCE6FF';
    }

    function colorCaja() {
        raton.parentNode.style.backgroundColor = '#FFF';
        teclado.parentNode.style.backgroundColor = '#FFF';
    }

    function informacion(e) {
        switch(e.type) {
            case 'mousemove':
                infoRaton(e);
                break;

            case 'keypress':
                infoTeclado(e);
                break;

            case 'click':
                colorClick(e);
                break;
      }
    }

    document.addEventListener('mousemove', informacion, false);
    document.addEventListener('mousemove', colorCaja, false);
    document.addEventListener('keypress', informacion, false);
    document.addEventListener('keypress', colorKey, false);
    document.addEventListener('click', informacion, false);
};