var Persona = (function() {
  function Persona(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;

    this.obtDetalles = function() {
      return ("Nombre : " + this.nombre + ", Edad : " + this.edad);
    };
  }

  Persona.prototype.obtDetalles = function() {
    return ("Nombre : " + this.nombre + ", Edad : " + this.edad);
  };

  return Persona;

})();

var Estudiante = (function(Persona) {
  function Estudiante(nombre, edad, curso, grupo) {
    Persona.call(this, nombre, edad);

    this.curso = curso;
    this.grupo = grupo;
  }

  Estudiante.prototype = new Persona();
  Estudiante.prototype.registrar = function() {
    return ("Estudiante " + this.nombre + " registrado en el curso " + this.curso);
  };

  return Estudiante;

})(Persona);

var Profesor = (function(Persona) {
  function Profesor(nombre, edad, asignatura, nivel) {
    Persona.call(this, nombre, edad);

    this.asignatura = asignatura;
    this.nivel = nivel;
  }

  Profesor.prototype = new Persona();
  Profesor.prototype.asignar = function() {
    return ("Profesor " + this.nombre + " asignado a la asignatura " + this.asignatura);
  };

  return Profesor;

})(Persona);

var e1 = new Estudiante("Arkaitz Garro", 31, "Desarrollo Web", "A1");
console.log(e1.obtDetalles());

var e2 = new Estudiante("Arkaitz Garro", 32, "Desarrollo Web", "A2");
console.log(e2.obtDetalles());

var p1 = new Profesor("Iñigo Garro", 45, "CMMI", "A2");
console.log(p1.obtDetalles());
console.log(p1.asignar());