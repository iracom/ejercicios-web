// Fechas "XX/XX/XXXX"
var datePattern = /\d{1,2}\/\d{1,2}\/(\d{2}|\d{4})\b/g;
var txt = "Nací el 5/4/1982 en Donostia. Vine a vivir a Rentería el 06/04/1982. Volví a Donostia el 1/10/10. Sigo viviendo aquí hasta hoy 6/5/13. Lafechaesta10/10/2010juntaconeltexto";
var fechas = txt.match(datePattern);
console.log(fechas);

var datePattern = /^(0?[1-9]|[12][0-9]|3[01])\/(0[1-9]|11|12)\/(\d{2}|\d{4})$/;
// var datePattern = var reg = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g;
console.log(datePattern.test("01/01/2014"));
console.log(datePattern.test("40/01/2014"));
console.log(datePattern.test("12/15/2014"));
console.log(datePattern.test("31/02/2014"));

// Email
var mailAddress = /^\w(?:(\w|\.|\-)*\w)?@\w(?:(\w|\.|\-)*\w)?\.[a-zA-Z]{2,3}$/;
console.log("arkaitz.garro@gmail.com " + mailAddress.test("arkaitz.garro@gmail.com"));
console.log("a@g.co " + mailAddress.test("a@g.co"));
console.log("@gmail.com " + mailAddress.test("@gmail.com"));
console.log("arkaitz.garro@gmail.com es una dirección de correo, pero no funciona... " + mailAddress.test("arkaitz.garro@gmail.com es una dirección de correo, pero no funciona..."));
console.log("arkaitz_garro@gmail.com " + mailAddress.test("arkaitz_garro@gmail.com"));

// escapeHTML
function escapeHTML(text) {
    var replacements = {"<": "&lt;", ">": "&gt;",
                        "&": "&amp;", "\"": "&quot;"};
    return text.replace(/[<>&"]/g, function(character) {
        return replacements[character];
    });
}
console.log(escapeHTML("The 'pre-formatted' tag is written \"<pre>\"."));

// reverse
var re = /(\w+)\s(.+)/;
console.log("John Smith".replace(re, "$2, $1"));
console.log("Arkaitz Garro Elgueta".replace(re, "$2, $1"));
console.log("Arkaitz".replace(re, "$2, $1"));

// Eliminar etiquetas de <script><\/script>
var txt = '<html><body bgcolor=linen><\nscript >alert("XSS");<\/script><p>' +
   'This is <b>bold<\/b><\/p><script>alert("XSS");<\/script><\/body><\/html>';

var tags = /<\s*?script[\s\S]*?>.*?<\/[\s\S]*?script[\s\S]*?>/ig;
console.log(txt.replace(tags, ''));