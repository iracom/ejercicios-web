// var num = prompt("Introduce un número para calcular el factorial");

var factorial = function(num) {
    var res = 1;

    num = parseInt(num);
    if(num > 0) {
        for (var i = 1; i <= num; i++) {
            res *= i;
        }
        console.log("El factorial de "+num+" es : "+res);
    }

    return res;
}

factorial(1);
factorial(10);
factorial(100);