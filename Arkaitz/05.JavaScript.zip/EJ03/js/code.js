var meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

console.log(meses);
alert(meses);

console.log(window);
alert(window);

for (mes in meses) {
	console.log("Mes "+mes+": "+meses[mes]);
};