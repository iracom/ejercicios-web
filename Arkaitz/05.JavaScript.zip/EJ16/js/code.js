window.$ = function(selector) {
    var e = document.querySelectorAll(selector);

    return (e.length == 1)? e[0] : e;
};

var anade = function () {
    var li  = document.createElement("li");
    var txt = document.createTextNode("Hola Mundo!");

    li.appendChild(txt);

    var lista = $("#lista");
    lista.appendChild(li);
};

setInterval(anade, 2000);