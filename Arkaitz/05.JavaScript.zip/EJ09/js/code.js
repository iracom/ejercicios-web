// var num = prompt("Introduce un número para calcular el factorial");

var mayMin = function(palabra) {
    var mayusculas = palabra.toUpperCase();
    var minusculas = palabra.toLowerCase();

    if(mayusculas === palabra) {
        console.log("La palabra está en mayusculas.");
    } else if(minusculas === palabra) {
        console.log("La palabra está en minusculas.");
    } else {
        console.log("La palabra está en mayusculas y minusculas.");
    }
}

console.log(mayMin("ARKAITZ"));
console.log(mayMin("Arkaitz"));
console.log(mayMin("arkaitz"));