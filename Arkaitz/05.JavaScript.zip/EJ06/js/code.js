// var $ = function(selector) {
//     var nodeList = document.querySelectorAll(selector);

//     return (nodeList.length == 1)? nodeList[0] : nodeList;
// };

var validarDni = function(dni) {
    var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];

    if(dni.length != 9) {
        console.log("La longitud del DNI es incorrecta.");
    } else {
        var dni_num = dni.substring(0, 8);
        var dni_char = dni.charAt(dni.length-1);

        var num = parseInt(dni_num, 10);
        if(num < 0 || num > 99999999) {
            console.log("El número es menor que 0 o mayor que 99999999.");
        } else {
            var resto = num % 23;
            var letra = letras[resto];
            if(letra.toUpperCase() == dni_char.toUpperCase())
                console.log("El DNI es correcto");
            else
                console.log("La letra no es correcta");
        }
    }
};

var letras = [];

validarDni('44153570x');
validarDni('44153571x');

// window.onload = function() {
//     var btnValidar = $('#validar');
//     btnValidar.addEventListener('click', function(e){
//         e.preventDefault();
//         var dniTxt = $('#dni');
//         Validadores.validarDni(dniTxt.value.trim());
//     }, false);
// };