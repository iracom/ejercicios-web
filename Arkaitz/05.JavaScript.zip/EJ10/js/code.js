// var num = prompt("Introduce un número para calcular el factorial");

var esPalindromo = function(palabra) {
    palindromo = palabra.trim().split("").reverse().join("").replace(/ /gi, "");
    palabra = palabra.trim().replace(/ /gi, "");

    return palabra.toLowerCase() === palindromo.toLowerCase();
}

console.log(esPalindromo("RADAR"));
console.log(esPalindromo("Arkaitz"));
console.log(esPalindromo("Reconocer"));
console.log(esPalindromo("La ruta nos aporto otro paso natural"));