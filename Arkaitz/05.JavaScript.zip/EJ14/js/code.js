window.$ = function(selector) {
    var e = document.querySelectorAll(selector);

    return (e.length == 1)? e[0] : e;
};

window.onload = function() {
    var end, start;

    start = new Date();
    // Numero de enlaces de la pagina
    var enlaces = $("a");
    console.log("Número de enlaces de la pagina: "+enlaces.length);

    // Direccion del penultimo enlace
    if(enlaces.length >= 2) {
        console.log("Direccion del penúltimo enlace: "+enlaces[enlaces.length-2].href);

        var enlace = $("p:nth-last-of-type(1) a:nth-last-child(2)")
        console.log("Direccion del penúltimo enlace: "+enlace.href);
    } else if(enlaces.length == 1) {
        console.log("Direccion del penúltimo enlace: "+enlaces[0].href);
    } else {
        console.log("No hay enlaces.");
    }

    // Numero de enlaces que apuntan a http://prueba
    enlaces = $('a[href="http://prueba"]');
    console.log("Número de enlaces que apuntan a http://prueba: "+enlaces.length);

    // Numero de enlaces del tercer párrafo
    enlaces = $("p:nth-child(3) a");
    console.log("Número de enlaces del tercer párrafo: "+enlaces.length);
    // var parrafos = document.getElementsByTagName("p");
    // if(parrafos[2] !== "undefined") {
    //     enlaces = parrafos[2].getElementsByTagName("a");
    //     console.log("Número de enlaces del tercer párrafo: "+enlaces.length);
    // }

    end = new Date();
    console.log("Operation took " + (end.getTime() - start.getTime()) + " msec");
}