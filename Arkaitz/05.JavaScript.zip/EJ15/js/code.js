window.$ = function(selector) {
    var e = document.querySelectorAll(selector);

    return (e.length == 1)? e[0] : e;
};

var muestra = function() {
    var oculto = $("#adicional");
    //oculto.style.display = 'inline';
    oculto.className = 'visible';

    var enlace = $("#enlace");
    //enlace.style.display = 'none';
    enlace.className = 'oculto';
};

setTimeout(muestra, 2000);