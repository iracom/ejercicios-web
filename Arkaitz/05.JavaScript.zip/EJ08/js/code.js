// var num = prompt("Introduce un número para calcular el factorial");

var esPar = function(num) {
    num = parseInt(num);

    return (num % 2) === 0;
}

console.log(esPar(1));
console.log(esPar(2));
console.log(esPar(3));