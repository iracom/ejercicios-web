var valores = [true, 5, false, "hola", "adios", 2];
var textos = [],
	booleanos = [],
	numeros = [];

// var textos = booleanos = numeros = [];

console.log(valores);

for (val in valores) {
	switch(typeof valores[val]) {
		case 'boolean':
			console.log(valores[val]+" es un valor de tipo boolean.");
			booleanos.push(valores[val]);
			break;
		case 'number':
			console.log(valores[val]+" es un valor de tipo number.");
			numeros.push(valores[val]);
			break;
		case 'string':
			console.log(valores[val]+" es un valor de tipo string.");
			textos.push(valores[val]);
			break;
	}
};

console.log(textos, booleanos, numeros);

if(textos[0] > textos[1])
	console.log(textos[0]+" es mayor que "+textos[1]);
else
	console.log(textos[1]+" es mayor que "+textos[0]);

console.log(booleanos[0] && !booleanos[1]);
console.log(!booleanos[0] || booleanos[1]);

console.log("La suma (+) es : "+(numeros[0]+numeros[1]));
console.log("La resta (-) es : "+(numeros[0]-numeros[1]));
console.log("La división (/) es : "+(numeros[0]/numeros[1]));
console.log("La multiplicación (*) es : "+(numeros[0]*numeros[1]));
console.log("El módulo (%) es : "+(numeros[0]%numeros[1]));