var $ = function(selector) {
    var e = document.querySelectorAll(selector);
    return (e.length == 1)? e[0] : e;
};

window.onload = function() {
    var $form        = $("#registro");
    var $nombre      = $("#registro_nombre");
    var $email       = $("#registro_email");
    var $password    = $("#registro_password");
    var $comentarios = $("#registro_comentarios");
    var $acepto      = $("#registro_condiciones");
    var $errores     = $(".errores");

    var validarForm = function(e){
        var errores = [];

        try {
            if(!validar.obligatorio($nombre.value)) {
                errores.push("El nombre es obligatorio.");
            }

            if(!validar.email($email.value)) {
                errores.push("El email no es una dirección válida.");
            }

            if(!validar.password($password.value)) {
                errores.push("El password no es válido.");
            }

            if(!validar.obligatorio($comentarios.value)) {
                errores.push("Los comentarios son obligatorios.");
            } else {
                if(!validar.max($comentarios.value, 50)) {
                    errores.push("Los comentarios no deben superar los 50 caracteres.");
                }
            }

            if(!$acepto.checked) {
                errores.push("Debes aceptar las condiciones del servicio.");
            }

            if(errores.length > 0) {
                $errores.innerHTML = "Se han producido los siguientes errores:<br> - "+errores.join("<br> - ");
                $errores.parentNode.className = 'visible';
                
                e.preventDefault();
                return false;
            }
        } catch(ex) {
            console.log(ex.message);
            e.preventDefault();
        }
    };

    var validaCampo = function() {
        switch(this.id){
            case "registro_nombre":
                if(!validar.obligatorio(this.value)) {
                    alert("El nombre es obligatorio.");
                }
                break;
            case "registro_email":
                if(!validar.email(this.value)) {
                    alert("El email no es una dirección válida.");
                }
                break;
            case "registro_password":
                if(!validar.password(this.value)) {
                    alert("El password no es válido.");
                }
                break;
            case "registro_comentarios":
                if(!validar.obligatorio(this.value)) {
                    alert("Los comentarios son obligatorios.");
                }

                if(!validar.max(this.value, 50)) {
                    alert("El número máximo de caracteres es 50.");
                }
                break;
        }
    };

    $form.addEventListener('submit', validarForm);
    $nombre.addEventListener('blur', validaCampo);
    $email.addEventListener('blur', validaCampo);
    $password.addEventListener('blur', validaCampo);
    $comentarios.addEventListener('blur', validaCampo);
};