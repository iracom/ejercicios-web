// Función global de selección
window.$ = function(selector) {
    var e = document.querySelectorAll(selector);
    return (e.length == 1)? e[0] : e;
};

window.onload = function() {
    // Todos los divs
    var divs = $("div");

    // Textos de los enlaces
    var txtOcultar = "Ocultar contenidos";
    var txtMostrar = "Mostrar contenidos";

    var enlaces = $("a");
    // Asignar una función a todos los enlaces al producirse un evento de click
    for (var i = 0; i < enlaces.length; i++) {
        enlaces[i].addEventListener("click", muestraOculta, false);
    }

    var toggle = {
        // Cambia la visibilidad del elemento p
        change : function(a, p) {
            p.className = (p.className === 'visible') ? 'oculto' : 'visible';
            a.innerText = (p.className === 'visible') ? txtOcultar : txtMostrar;
        },
        // Esconde el elemento p
        hide : function(a, p) {
            p.className = 'oculto';
            a.innerText = txtMostrar;
        },
        // Muestra el elemento p
        show : function(a, p) {
            p.className = 'visible';
            a.innerText = txtOcultar;
        }
    };

    function muestraOculta(e) {
        e.preventDefault();

        // Accedemos al primer parrafo dentro del mismo contenedor
        var p = this.parentNode.querySelector("p:first-child");
        toggle.change(this, p);

        for (var i = 0; i < divs.length; i++) {
            // Recorremos todos los parrafos del documento
            var div_p = divs[i].querySelector("p");
            var div_a = divs[i].querySelector("a");

            if(p !== div_p) {
                // Escondo el elemento p si no es el actual
                toggle.hide(div_a, div_p);
            }
        }
    }
};