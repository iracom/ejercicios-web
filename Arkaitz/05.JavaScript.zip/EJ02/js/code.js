var mensaje = "Hola mundo!\nQué fácil es incluir 'comillas simples'\ny comillas \"dobles\"";

alert(mensaje);