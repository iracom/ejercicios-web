<?php
    $consumer_key = "oHtg0L8NrNOiT2jwDmm3xA"; 
    $consumer_secret = "D7b0t2gawQVSOEHE8VMwPP0SSBZqOpCQOw5Upvska4";
    $user_token = "21924379-ngQbhJDbscM1F0hqbGsm11pcGOSf3ciPyF4nP5F3B";
    $user_secret = "PNhINN3DXyiFobFJTz10w4roc1AAoFVtcxFX8LN7pBJuy";
?>